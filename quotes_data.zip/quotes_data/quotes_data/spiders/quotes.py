import scrapy
from quotes_data.items import QuotesDataItem    # import Item


class QuotesSpider(scrapy.Spider):
    name = "quotes"
    allowed_domains = ["quotes.toscrape.com"]
    start_urls = ["https://quotes.toscrape.com"]

    def parse(self, response):
        quotes = response.css('div.quote')     # 获取response中 所有 class 为 quote 的 div
        for quote in quotes:                # 遍历以获取每条名言的text、author和tags
            item = QuotesDataItem()
            item['text'] = quote.css('span.text::text').get() # text
            item['author'] = quote.css('small.author::text').get() # author
            item['tags'] = quote.css('div.tags a.tag::text').getall() # tags
            yield item
        
        next_page = response.css('li.next a::attr(href)').get()
        if next_page is not None:
            next_page = response.urljoin(next_page)
            yield scrapy.Request(next_page, callback=self.parse)


